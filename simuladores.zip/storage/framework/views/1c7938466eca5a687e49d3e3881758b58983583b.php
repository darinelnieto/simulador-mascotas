
<?php $__env->startSection('content'); ?>
<!--<div class="escritorio">
    <div class="panelIzq">
        <h2 class="txtDesc">Línea de producto orientada a diferentes tipos de <br>
            productores; según su negocio y necesidad pecuaria. <br>Se compone de dos portafolios de producto.</h2>
        <img src="<?php echo e(asset('/img/divisor.png/')); ?>">

        <form action="<?php echo e(route('simulador_piscicultura')); ?>" method="get">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="imgClave" name="imgClave" value="">
            <div class="contAguas">
                <input type="radio" name="AFC" value="AF" id="AF">
                <label class="txtAguas" for="AF">Aguas Frías</label>
                <input type="radio" name="AFC" value="AC" id="AC">
                <label class="txtAguas" for="AC">Aguas Cálidas</label>
            </div>
            <div>
                <h2>Especies</h2>
            </div>
            <div>
                <select id="especie" name="especie" required="required">


                </select>
            </div>
            <div>
                <input class="btnSubmit" type="submit" value="Ir al simulador">
            </div>
        </form>
    </div>
    <div class="panelDir">
        <img class="bannerDir" id="imgAguas" src="<?php echo e(asset('/img/bannerAguasCalidas.png/')); ?>">
        <img src="<?php echo e(asset('/img/logosEscritorio.png/')); ?>" width="200px">
    </div>
</div>-->
<div class="container-fluid fondo">
    <div class="row">
        <div class="col-12 col-md-6 text-center my-5">
            <h2 class="txtDesc">Línea de producto orientada a diferentes tipos de <br>
                productores; según su negocio y necesidad pecuaria. <br>Se compone de dos portafolios de producto.</h2>
            <img src="<?php echo e(asset('/img/divisor.png/')); ?>" width="100%">

            <form action="<?php echo e(route('simulador_piscicultura')); ?>" method="get">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="imgClave" name="imgClave" value="">
                <div class="contAguas">
                    <input type="radio" name="AFC" value="AF" id="AF">
                    <label class="txtAguas" for="AF">Aguas Frías</label>
                    <input type="radio" name="AFC" value="AC" id="AC">
                    <label class="txtAguas" for="AC">Aguas Cálidas</label>
                </div>
                <div>
                    <h2>Especies</h2>
                </div>
                <div>
                    <select id="especie" name="especie" required="required">


                    </select>
                </div>
                <div>
                    <input class="btnSubmit" type="submit" value="Ir al simulador">
                </div>
            </form>
        </div>
        <div class="col-12 col-md-6 text-center centrado-vertical">
            <img class="bannerDir" id="imgAguas" src="<?php echo e(asset('/img/bannerAguasCalidas.png/')); ?>">
            <img src="<?php echo e(asset('/img/logosEscritorioNutricion.png/')); ?>" width="200px" class="mt-3">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('piscicultura.plantilla.plantillaPiscicultura', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simuladores\resources\views/piscicultura/piscicultura.blade.php ENDPATH**/ ?>