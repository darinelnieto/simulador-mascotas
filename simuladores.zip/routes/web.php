<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/piscicultura', 'App\Http\Controllers\PisciculturaController@index')->name('piscicultura');

Route::get('/simulador_piscicultura', 'App\Http\Controllers\PisciculturaController@index_simulador')->name('simulador_piscicultura');

Route::get('/piscicultura_simulado', 'App\Http\Controllers\PisciculturaController@index_simulado')->name('piscicultura_simulado');

Route::name('pdf_piscicultura')->get('/pdf_piscicultura', 'App\Http\Controllers\PisciculturaController@generar_pdf');